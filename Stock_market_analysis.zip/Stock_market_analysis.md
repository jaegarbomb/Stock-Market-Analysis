
# Stock market Analysis

In this project, we will be analysis stock data for a few car companies from Jan-1 2012 to Jan-1 2017.



```python
# Importing the libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
```

## Getting the Data


```python
# Import the datasets.
ford = pd.read_csv("Ford_stock.csv", parse_dates=True, index_col='Date')
gm = pd.read_csv("GM_Stock.csv",  parse_dates=True, index_col='Date')
tesla = pd.read_csv("Tesla_Stock.csv",  parse_dates=True, index_col='Date')
```

## Visualization of data

### Plotting opening prices and volumes.


```python
tesla['Open'].plot(label='Tesla', figsize=(16,8))
gm['Open'].plot(label='GM')
ford['Open'].plot(label='Ford')
plt.title("Open Prices")

plt.legend();
```


![png](output_7_0.png)


### Volume of stock traded each day.


```python
tesla['Volume'].plot(label='Tesla', figsize=(16,8))
gm['Volume'].plot(label='GM')
ford['Volume'].plot(label='Ford')

plt.title("Volume Traded")
plt.legend();
```


![png](output_9_0.png)


Inference:
It looks like Ford had a massive spike of trading somewhere around late 2013. 


```python
# The date when the highest volume of Trading of Ford Stocks was done.
ford['Volume'].idxmax()

# 18th Dec-13
```




    Timestamp('2013-12-18 00:00:00')



## Story behind the huge trade amount.
Ford announced that the cost of launching products would cut into the profits. This news led to huge amount of selloffs.


```python
ford['Open'].plot(figsize = (16,4))
plt.xlim(['2013-12-01','2014-01-31'])
```




    (735203.0, 735264.0)




![png](output_13_1.png)



```python
ford['Open'].plot(figsize = (16,4))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x4b4b60bc88>




![png](output_14_1.png)


It can be seen that there is a slight dip in Opening Price


```python
tesla['Total_Traded'] = tesla['Open'] *  tesla['Volume']
#tesla.drop(columns=['Total_Traded($)'], inplace=True)  # -> This was done, as I had accidently names the column wrongly.
tesla.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>28.94</td>
      <td>29.50</td>
      <td>27.65</td>
      <td>28.08</td>
      <td>928052</td>
      <td>26857824.88</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>28.21</td>
      <td>28.67</td>
      <td>27.50</td>
      <td>27.71</td>
      <td>630036</td>
      <td>17773315.56</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>27.76</td>
      <td>27.93</td>
      <td>26.85</td>
      <td>27.12</td>
      <td>1005432</td>
      <td>27910792.32</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>27.20</td>
      <td>27.79</td>
      <td>26.41</td>
      <td>26.89</td>
      <td>687081</td>
      <td>18688603.20</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>27.00</td>
      <td>27.49</td>
      <td>26.12</td>
      <td>27.25</td>
      <td>896951</td>
      <td>24217677.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
gm['Total_Traded'] = gm['Open'] *  gm['Volume']
gm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>20.83</td>
      <td>21.18</td>
      <td>20.75</td>
      <td>21.05</td>
      <td>9321420</td>
      <td>1.941652e+08</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>21.05</td>
      <td>21.37</td>
      <td>20.75</td>
      <td>21.15</td>
      <td>7856752</td>
      <td>1.653846e+08</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>21.10</td>
      <td>22.29</td>
      <td>20.96</td>
      <td>22.17</td>
      <td>17884040</td>
      <td>3.773532e+08</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>22.26</td>
      <td>23.03</td>
      <td>22.24</td>
      <td>22.92</td>
      <td>18234608</td>
      <td>4.059024e+08</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>23.20</td>
      <td>23.43</td>
      <td>22.70</td>
      <td>22.84</td>
      <td>12091714</td>
      <td>2.805278e+08</td>
    </tr>
  </tbody>
</table>
</div>




```python
ford['Total_Traded'] = ford['Open'] *  ford['Volume']
ford.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>11.00</td>
      <td>11.25</td>
      <td>10.99</td>
      <td>11.13</td>
      <td>45709811</td>
      <td>5.028079e+08</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>11.15</td>
      <td>11.53</td>
      <td>11.07</td>
      <td>11.30</td>
      <td>79725188</td>
      <td>8.889358e+08</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>11.33</td>
      <td>11.63</td>
      <td>11.24</td>
      <td>11.59</td>
      <td>67877467</td>
      <td>7.690517e+08</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>11.74</td>
      <td>11.80</td>
      <td>11.52</td>
      <td>11.71</td>
      <td>59840605</td>
      <td>7.025287e+08</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>11.83</td>
      <td>11.95</td>
      <td>11.70</td>
      <td>11.80</td>
      <td>53981467</td>
      <td>6.386008e+08</td>
    </tr>
  </tbody>
</table>
</div>



### Visualizing the Total Traded qty.

tesla['Total_Traded'].plot(label = 'Tesla', figsize = (16,8))
gm['Total_Traded'].plot()
ford['Total_Traded'].plot()

plt.legend();

Let us check which date is the biggest spike for Tesla.


```python
tesla['Total_Traded'].idxmax()
```




    Timestamp('2014-02-25 00:00:00')



Thus, on 25th Feb 2014, Tesla saw a huge amount of trading of their stocks.
This was due to a Mogan Stanley analyst giving out a bullish research report to clients that favoured Tesla. 


# Visualization of Moving Averages.
Here we will be plotting Moving Averages of stocks over 50 days and 200 days.


```python
gm['MA50'] = gm['Open'].rolling(50).mean()
gm['MA200'] = gm['Open'].rolling(200).mean()
gm[['Open','MA50','MA200']].plot(label='gm',figsize=(16,8))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x4b4b737c88>




![png](output_25_1.png)


Now I will try and see if there is any relationship between those stocks, as they are all related to the Car Industry.
This can be seen by a Scatter Matrix plot.


```python
from pandas.plotting import scatter_matrix
```


```python
car_comp_df = pd.concat([tesla['Open'], gm['Open'], ford['Open']], axis=1)
car_comp_df.head()
## Rename Columns

#car_comp_df.rename(axis=1, mapper={'Open':'Tesla', 'Open':'GM', 'Open':'Ford'}) 
# This didn't work as every column name was replaced by Ford, as that was the latest name.
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>Open</th>
      <th>Open</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>28.94</td>
      <td>20.83</td>
      <td>11.00</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>28.21</td>
      <td>21.05</td>
      <td>11.15</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>27.76</td>
      <td>21.10</td>
      <td>11.33</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>27.20</td>
      <td>22.26</td>
      <td>11.74</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>27.00</td>
      <td>23.20</td>
      <td>11.83</td>
    </tr>
  </tbody>
</table>
</div>




```python
car_comp_df.columns = ['Tesla_Open','GM_Open','Ford_Open']
car_comp_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tesla_Open</th>
      <th>GM_Open</th>
      <th>Ford_Open</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>28.94</td>
      <td>20.83</td>
      <td>11.00</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>28.21</td>
      <td>21.05</td>
      <td>11.15</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>27.76</td>
      <td>21.10</td>
      <td>11.33</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>27.20</td>
      <td>22.26</td>
      <td>11.74</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>27.00</td>
      <td>23.20</td>
      <td>11.83</td>
    </tr>
  </tbody>
</table>
</div>




```python
scatter_matrix(car_comp_df, figsize=(10,10));
```


![png](output_30_0.png)



```python
scatter_matrix(car_comp_df, figsize=(10,10), alpha=0.2, hist_kwds={'bins':50} );
```


![png](output_31_0.png)


# Basic Financial Anaylsis

## Daily Percentage Change
Daily percentage change is defined by the following formula:

$ r_t = \frac{p_t}{p_{t-1}} -1$

This defines r_t (return at time t) as equal to the price at time t divided by the price at time t-1 (the previous day) minus 1. Basically this just informs you of your percent gain (or loss) if you bought the stock on day and then sold it the next day. While this isn't necessarily helpful for attempting to predict future values of the stock, its very helpful in analyzing the volatility of the stock. If daily returns have a wide distribution, the stock is more volatile from one day to the next. Let's calculate the percent returns and then plot them with a histogram, and decide which stock is the most stable!


```python
# Create a new Returns column.
#tesla['returns'] = (tesla['Close'] / tesla['Close'].shift(1) ) - 1
# Tesla.head()
```


```python
tesla['Returns'] =  tesla['Close'].pct_change(1)
tesla.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
      <th>Returns</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>28.94</td>
      <td>29.50</td>
      <td>27.65</td>
      <td>28.08</td>
      <td>928052</td>
      <td>26857824.88</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>28.21</td>
      <td>28.67</td>
      <td>27.50</td>
      <td>27.71</td>
      <td>630036</td>
      <td>17773315.56</td>
      <td>-0.013177</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>27.76</td>
      <td>27.93</td>
      <td>26.85</td>
      <td>27.12</td>
      <td>1005432</td>
      <td>27910792.32</td>
      <td>-0.021292</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>27.20</td>
      <td>27.79</td>
      <td>26.41</td>
      <td>26.89</td>
      <td>687081</td>
      <td>18688603.20</td>
      <td>-0.008481</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>27.00</td>
      <td>27.49</td>
      <td>26.12</td>
      <td>27.25</td>
      <td>896951</td>
      <td>24217677.00</td>
      <td>0.013388</td>
    </tr>
  </tbody>
</table>
</div>




```python
ford['Returns'] =  ford['Close'].pct_change(1)
ford.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
      <th>Returns</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>11.00</td>
      <td>11.25</td>
      <td>10.99</td>
      <td>11.13</td>
      <td>45709811</td>
      <td>5.028079e+08</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>11.15</td>
      <td>11.53</td>
      <td>11.07</td>
      <td>11.30</td>
      <td>79725188</td>
      <td>8.889358e+08</td>
      <td>0.015274</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>11.33</td>
      <td>11.63</td>
      <td>11.24</td>
      <td>11.59</td>
      <td>67877467</td>
      <td>7.690517e+08</td>
      <td>0.025664</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>11.74</td>
      <td>11.80</td>
      <td>11.52</td>
      <td>11.71</td>
      <td>59840605</td>
      <td>7.025287e+08</td>
      <td>0.010354</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>11.83</td>
      <td>11.95</td>
      <td>11.70</td>
      <td>11.80</td>
      <td>53981467</td>
      <td>6.386008e+08</td>
      <td>0.007686</td>
    </tr>
  </tbody>
</table>
</div>




```python
gm['Returns'] =  gm['Close'].pct_change(1)
gm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
      <th>MA50</th>
      <th>MA200</th>
      <th>Returns</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>20.83</td>
      <td>21.18</td>
      <td>20.75</td>
      <td>21.05</td>
      <td>9321420</td>
      <td>1.941652e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>21.05</td>
      <td>21.37</td>
      <td>20.75</td>
      <td>21.15</td>
      <td>7856752</td>
      <td>1.653846e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.004751</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>21.10</td>
      <td>22.29</td>
      <td>20.96</td>
      <td>22.17</td>
      <td>17884040</td>
      <td>3.773532e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.048227</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>22.26</td>
      <td>23.03</td>
      <td>22.24</td>
      <td>22.92</td>
      <td>18234608</td>
      <td>4.059024e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.033829</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>23.20</td>
      <td>23.43</td>
      <td>22.70</td>
      <td>22.84</td>
      <td>12091714</td>
      <td>2.805278e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>-0.003490</td>
    </tr>
  </tbody>
</table>
</div>




```python
ford['Returns'].hist(bins=50, figsize = (10,6));
plt.title("Ford - Returns")
```




    Text(0.5,1,'Ford - Returns')




![png](output_40_1.png)



```python
gm['Returns'].hist(bins=50, figsize = (10,6));
plt.title("General Motor - Returns")
```




    Text(0.5,1,'General Motor - Returns')




![png](output_41_1.png)



```python
tesla['Returns'].hist(bins=50, figsize = (10,6));
plt.title("Tesla - Returns")
```




    Text(0.5,1,'Tesla - Returns')




![png](output_42_1.png)


Now to properly compare the histograms, let's stack it on top of each other.


```python
tesla['Returns'].hist(bins=50, figsize = (12,8),label="Tesla", alpha = 0.5)
ford['Returns'].hist(bins=50, figsize = (12,8), label='Ford', alpha = 0.5)
gm['Returns'].hist(bins=50, figsize = (12,8), label="GM", alpha = 0.5)
plt.legend()
plt.title("Returns");
```


![png](output_44_0.png)


From the above histogram, we can see that Tesla stocks are quite volatile.

### Now I will run a Kernel Density Estimation Plot.


```python
tesla['Returns'].plot(kind='kde', label='Tesla', figsize = (16,4) )
ford['Returns'].plot(kind='kde', label='Ford', figsize = (16,4))
gm['Returns'].plot(kind='kde', label='GM', figsize = (16,4))
plt.title("KDE Plots for Returns")
plt.legend;
```


![png](output_47_0.png)


## Boxplots
Now the stocks are compared using boxplots.


```python
box_df = pd.concat(objs=[tesla['Returns'], gm['Returns'], ford['Returns']], axis=1)
box_df.columns= ('Tesla', 'Ford','GM')
box_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tesla</th>
      <th>Ford</th>
      <th>GM</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>-0.013177</td>
      <td>0.004751</td>
      <td>0.015274</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>-0.021292</td>
      <td>0.048227</td>
      <td>0.025664</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>-0.008481</td>
      <td>0.033829</td>
      <td>0.010354</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>0.013388</td>
      <td>-0.003490</td>
      <td>0.007686</td>
    </tr>
  </tbody>
</table>
</div>




```python
box_df.boxplot(figsize=(6,12), grid=False)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x4b4967af28>




![png](output_50_1.png)


## Studying Correlation between Daily Returns using a Scatter Matrix.


```python
scatter_matrix(box_df, figsize=(8,8), alpha=0.5, hist_kwds={'bins':100});
```


![png](output_52_0.png)



```python
#box_df.columns
box_df.plot(kind='scatter', x='Ford', y='GM',figsize=(8,8), title="GM-Ford");
```


![png](output_53_0.png)



```python
box_df.plot(kind='scatter', x='Ford', y='Tesla',figsize=(8,8), title="Tesla-Ford");
```


![png](output_54_0.png)



```python
box_df.plot(kind='scatter', x='Ford', y='Tesla',figsize=(8,8), title="Tesla-Ford");
```


![png](output_55_0.png)



```python
box_df.plot(kind='scatter', x='GM', y='Tesla',figsize=(8,8), title='Tesla-GM');
```


![png](output_56_0.png)


# Cumulative Returns

It is defined as the aggregrate amount an investment has lost or gained over time, indpendent of the period of time involved.
* Different from stock price at the current day.
* Takes in the account of the daily returns the stock gives to the investor.


## Formula for cumulative return:

$ i_i = (1+r_t) * i_{t-1} $

Here we can see we are just multiplying our previous investment at i at t-1 by 1+our percent returns. Pandas makes this very simple to calculate with its cumprod() method. Using something in the following manner:

    df[daily_cumulative_return] = ( 1 + df[pct_daily_return] ).cumprod()
    


```python
# Creating New columns for Cumulative Daily Return:
tesla['Cm_d_ret'] = (1 + tesla['Returns']).cumprod()
tesla.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
      <th>Returns</th>
      <th>Cm_d_ret</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>28.94</td>
      <td>29.50</td>
      <td>27.65</td>
      <td>28.08</td>
      <td>928052</td>
      <td>26857824.88</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>28.21</td>
      <td>28.67</td>
      <td>27.50</td>
      <td>27.71</td>
      <td>630036</td>
      <td>17773315.56</td>
      <td>-0.013177</td>
      <td>0.986823</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>27.76</td>
      <td>27.93</td>
      <td>26.85</td>
      <td>27.12</td>
      <td>1005432</td>
      <td>27910792.32</td>
      <td>-0.021292</td>
      <td>0.965812</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>27.20</td>
      <td>27.79</td>
      <td>26.41</td>
      <td>26.89</td>
      <td>687081</td>
      <td>18688603.20</td>
      <td>-0.008481</td>
      <td>0.957621</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>27.00</td>
      <td>27.49</td>
      <td>26.12</td>
      <td>27.25</td>
      <td>896951</td>
      <td>24217677.00</td>
      <td>0.013388</td>
      <td>0.970442</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Creating New columns for Cumulative Daily Return:
ford['Cm_d_ret'] = (1 + ford['Returns']).cumprod()
ford.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
      <th>Returns</th>
      <th>Cm_d_ret</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>11.00</td>
      <td>11.25</td>
      <td>10.99</td>
      <td>11.13</td>
      <td>45709811</td>
      <td>5.028079e+08</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>11.15</td>
      <td>11.53</td>
      <td>11.07</td>
      <td>11.30</td>
      <td>79725188</td>
      <td>8.889358e+08</td>
      <td>0.015274</td>
      <td>1.015274</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>11.33</td>
      <td>11.63</td>
      <td>11.24</td>
      <td>11.59</td>
      <td>67877467</td>
      <td>7.690517e+08</td>
      <td>0.025664</td>
      <td>1.041330</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>11.74</td>
      <td>11.80</td>
      <td>11.52</td>
      <td>11.71</td>
      <td>59840605</td>
      <td>7.025287e+08</td>
      <td>0.010354</td>
      <td>1.052111</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>11.83</td>
      <td>11.95</td>
      <td>11.70</td>
      <td>11.80</td>
      <td>53981467</td>
      <td>6.386008e+08</td>
      <td>0.007686</td>
      <td>1.060198</td>
    </tr>
  </tbody>
</table>
</div>




```python
#gm.drop(['MA50', 'MA200'], axis=1, inplace=True)
# Creating New columns for Cumulative Daily Return:
gm['Cm_d_ret'] = (1 + gm['Returns']).cumprod()
gm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Total_Traded</th>
      <th>MA50</th>
      <th>MA200</th>
      <th>Returns</th>
      <th>Cm_d_ret</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>20.83</td>
      <td>21.18</td>
      <td>20.75</td>
      <td>21.05</td>
      <td>9321420</td>
      <td>1.941652e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>21.05</td>
      <td>21.37</td>
      <td>20.75</td>
      <td>21.15</td>
      <td>7856752</td>
      <td>1.653846e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.004751</td>
      <td>1.004751</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>21.10</td>
      <td>22.29</td>
      <td>20.96</td>
      <td>22.17</td>
      <td>17884040</td>
      <td>3.773532e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.048227</td>
      <td>1.053207</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>22.26</td>
      <td>23.03</td>
      <td>22.24</td>
      <td>22.92</td>
      <td>18234608</td>
      <td>4.059024e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.033829</td>
      <td>1.088836</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>23.20</td>
      <td>23.43</td>
      <td>22.70</td>
      <td>22.84</td>
      <td>12091714</td>
      <td>2.805278e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>-0.003490</td>
      <td>1.085036</td>
    </tr>
  </tbody>
</table>
</div>




```python
tesla['Cm_d_ret'].plot(label = 'Tesla', figsize=(16,6))
ford['Cm_d_ret'].plot(label = 'Ford', figsize=(16,6))
gm['Cm_d_ret'].plot(label = 'GM', figsize=(16,6))
plt.title("Cumulative Returns of Tesla-Ford-GM")
plt.legend();
```


![png](output_64_0.png)



```python
ford['Cm_d_ret'].plot(label = 'Ford', figsize=(16,6))
gm['Cm_d_ret'].plot(label = 'GM', figsize=(16,6))
plt.title("Cumulative Returns of Tesla-Ford-GM")
plt.legend();
```


![png](output_65_0.png)


# **********************End of Project**************************
